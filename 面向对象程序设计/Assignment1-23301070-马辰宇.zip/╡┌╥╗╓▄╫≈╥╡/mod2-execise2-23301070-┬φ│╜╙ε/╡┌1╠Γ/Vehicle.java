public class Vehicle {
    public double load,maxLoad;
    public Vehicle(double m)
    {
        maxLoad=m;
    }
    public double getLoad()
    {
        return load;
    }
    public double getMaxLoad()
    {
        return maxLoad;
    }
}
