public class MyPoint {
  public int x;
  public int y;

  public String toString() {
    return ("[" + x + "," + y + "]");
  }
}

